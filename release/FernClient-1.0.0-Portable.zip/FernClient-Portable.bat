@echo off
set FERN_HOME=%~dp0data
start "" "%~dp0dist-electron\main.cjs"
