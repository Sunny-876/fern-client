"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// launcher/src/preload.ts
var preload_exports = {};
module.exports = __toCommonJS(preload_exports);
var import_electron = require("electron");
var api = {
  getVersion: () => import_electron.ipcRenderer.invoke("fern:get-version"),
  getBasePath: () => import_electron.ipcRenderer.invoke("fern:get-base-path"),
  minimizeWindow: () => import_electron.ipcRenderer.send("fern:window:minimize"),
  maximizeWindow: () => import_electron.ipcRenderer.send("fern:window:maximize"),
  closeWindow: () => import_electron.ipcRenderer.send("fern:window:close"),
  getSettings: () => import_electron.ipcRenderer.invoke("fern:settings:get"),
  updateSettings: (s) => import_electron.ipcRenderer.invoke("fern:settings:update", s),
  getAccounts: () => import_electron.ipcRenderer.invoke("fern:accounts:get"),
  getActiveAccount: () => import_electron.ipcRenderer.invoke("fern:accounts:get-active"),
  selectAccount: (id) => import_electron.ipcRenderer.invoke("fern:accounts:select", id),
  createLocalAccount: (dto) => import_electron.ipcRenderer.invoke("fern:accounts:create-local", dto),
  removeAccount: (id) => import_electron.ipcRenderer.invoke("fern:accounts:remove", id),
  getVersionManifest: (forceRefresh) => import_electron.ipcRenderer.invoke("fern:versions:get-manifest", forceRefresh),
  getVersionsList: (opts) => import_electron.ipcRenderer.invoke("fern:versions:get-list", opts),
  installVersion: (versionId) => import_electron.ipcRenderer.invoke("fern:versions:install", versionId),
  cancelInstallVersion: (versionId) => import_electron.ipcRenderer.invoke("fern:versions:cancel-install", versionId),
  onInstallProgress: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:install-progress", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:install-progress", handler);
  },
  getInstallations: () => import_electron.ipcRenderer.invoke("fern:installations:get"),
  getActiveInstallation: () => import_electron.ipcRenderer.invoke("fern:installations:get-active"),
  selectInstallation: (id) => import_electron.ipcRenderer.invoke("fern:installations:select", id),
  createInstallation: (dto) => import_electron.ipcRenderer.invoke("fern:installations:create", dto),
  updateInstallation: (id, dto) => import_electron.ipcRenderer.invoke("fern:installations:update", id, dto),
  duplicateInstallation: (id) => import_electron.ipcRenderer.invoke("fern:installations:duplicate", id),
  deleteInstallation: (id, deleteFiles) => import_electron.ipcRenderer.invoke("fern:installations:delete", id, deleteFiles),
  openInstallationFolder: (id) => import_electron.ipcRenderer.invoke("fern:installations:open-folder", id),
  getProfiles: () => import_electron.ipcRenderer.invoke("fern:profiles:get"),
  getActiveProfile: () => import_electron.ipcRenderer.invoke("fern:profiles:get-active"),
  selectProfile: (id) => import_electron.ipcRenderer.invoke("fern:profiles:select", id),
  createProfile: (dto) => import_electron.ipcRenderer.invoke("fern:profiles:create", dto),
  deleteProfile: (id) => import_electron.ipcRenderer.invoke("fern:profiles:delete", id),
  detectJava: () => import_electron.ipcRenderer.invoke("fern:java:detect"),
  getJavaRuntimes: () => import_electron.ipcRenderer.invoke("fern:java:get-runtimes"),
  launchMinecraft: (config) => import_electron.ipcRenderer.invoke("fern:launch:start", config),
  onLaunchStatus: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:launch-status", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:launch-status", handler);
  },
  getRecentLogs: (limit) => import_electron.ipcRenderer.invoke("fern:logs:get-recent", limit),
  getLogFilePath: () => import_electron.ipcRenderer.invoke("fern:logs:get-file-path"),
  openLogsFolder: () => import_electron.ipcRenderer.invoke("fern:logs:open-folder"),
  onLogEntry: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:log-entry", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:log-entry", handler);
  },
  getActiveDownloads: () => import_electron.ipcRenderer.invoke("fern:downloads:get-active"),
  cancelDownload: (id) => import_electron.ipcRenderer.invoke("fern:downloads:cancel", id),
  onDownloadProgress: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:download-progress", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:download-progress", handler);
  },
  getDownloadQueue: () => import_electron.ipcRenderer.invoke("fern:downloads:get-queue"),
  getQueueSummary: () => import_electron.ipcRenderer.invoke("fern:downloads:get-queue-summary"),
  clearDownloadQueue: () => import_electron.ipcRenderer.invoke("fern:downloads:clear-queue"),
  // Mod Loaders
  getLoaders: () => import_electron.ipcRenderer.invoke("fern:loaders:get-all"),
  getLoaderVersions: (loader, mcVersion) => import_electron.ipcRenderer.invoke("fern:loaders:get-versions", loader, mcVersion),
  installLoader: (instId, loaderVer) => import_electron.ipcRenderer.invoke("fern:loaders:install", instId, loaderVer),
  // Mods
  getInstalledMods: (instId) => import_electron.ipcRenderer.invoke("fern:mods:get-installed", instId),
  toggleMod: (instId, filePath) => import_electron.ipcRenderer.invoke("fern:mods:toggle", instId, filePath),
  toggleAllMods: (instId, enable) => import_electron.ipcRenderer.invoke("fern:mods:toggle-all", instId, enable),
  removeMod: (instId, filePath) => import_electron.ipcRenderer.invoke("fern:mods:remove", instId, filePath),
  searchMods: (opts) => import_electron.ipcRenderer.invoke("fern:mods:search", opts),
  getModProject: (projId) => import_electron.ipcRenderer.invoke("fern:mods:get-project", projId),
  getModVersions: (projId, mcVer, loader) => import_electron.ipcRenderer.invoke("fern:mods:get-versions", projId, mcVer, loader),
  getModDependencies: (verId) => import_electron.ipcRenderer.invoke("fern:mods:get-dependencies", verId),
  installMod: (instId, url, fileName, sha1) => import_electron.ipcRenderer.invoke("fern:mods:install", instId, url, fileName, sha1),
  validateModConflicts: (instId) => import_electron.ipcRenderer.invoke("fern:mods:validate-conflicts", instId),
  openModsFolder: (instId) => import_electron.ipcRenderer.invoke("fern:mods:open-folder", instId),
  // Packs
  getResourcePacks: (instId) => import_electron.ipcRenderer.invoke("fern:packs:get-resource-packs", instId),
  toggleResourcePack: (instId, path) => import_electron.ipcRenderer.invoke("fern:packs:toggle-resource-pack", instId, path),
  removeResourcePack: (path) => import_electron.ipcRenderer.invoke("fern:packs:remove-resource-pack", path),
  openResourcePacksFolder: (instId) => import_electron.ipcRenderer.invoke("fern:packs:open-resource-packs-folder", instId),
  getShaderPacks: (instId) => import_electron.ipcRenderer.invoke("fern:packs:get-shader-packs", instId),
  toggleShaderPack: (instId, path) => import_electron.ipcRenderer.invoke("fern:packs:toggle-shader-pack", instId, path),
  removeShaderPack: (path) => import_electron.ipcRenderer.invoke("fern:packs:remove-shader-pack", path),
  openShaderPacksFolder: (instId) => import_electron.ipcRenderer.invoke("fern:packs:open-shader-packs-folder", instId),
  // Modpacks
  importModpack: (archivePath) => import_electron.ipcRenderer.invoke("fern:modpacks:import", archivePath),
  exportModpack: (instId, dest) => import_electron.ipcRenderer.invoke("fern:modpacks:export", instId, dest),
  onModpackImportProgress: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:modpack-progress", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:modpack-progress", handler);
  },
  selectArchiveFile: () => import_electron.ipcRenderer.invoke("fern:dialog:select-archive"),
  selectExportPath: (defaultName) => import_electron.ipcRenderer.invoke("fern:dialog:select-export-path", defaultName),
  // Performance
  getPerformanceSettings: () => import_electron.ipcRenderer.invoke("fern:performance:get-settings"),
  updatePerformanceSettings: (s) => import_electron.ipcRenderer.invoke("fern:performance:update-settings", s),
  getInstancePerformanceSettings: (id) => import_electron.ipcRenderer.invoke("fern:performance:get-instance-settings", id),
  getRamRecommendation: (id) => import_electron.ipcRenderer.invoke("fern:performance:get-ram-recommendation", id),
  getJvmPreview: (id, jv) => import_electron.ipcRenderer.invoke("fern:performance:get-jvm-preview", id, jv),
  runBenchmark: (id, p, d) => import_electron.ipcRenderer.invoke("fern:performance:run-benchmark", id, p, d),
  getBenchmarkHistory: () => import_electron.ipcRenderer.invoke("fern:performance:get-benchmark-history"),
  compareBenchmarks: (b, o) => import_electron.ipcRenderer.invoke("fern:performance:compare-benchmarks", b, o),
  getHardwareInfo: () => import_electron.ipcRenderer.invoke("fern:performance:get-hardware-info"),
  // Phase 8 & 11 - Updates
  checkForUpdates: (channel) => import_electron.ipcRenderer.invoke("fern:updates:check", channel),
  setUpdateChannel: (channel) => import_electron.ipcRenderer.invoke("fern:updates:set-channel", channel),
  getUpdateChannel: () => import_electron.ipcRenderer.invoke("fern:updates:get-channel"),
  rollbackUpdate: () => import_electron.ipcRenderer.invoke("fern:updates:rollback"),
  hasRollbackAvailable: () => import_electron.ipcRenderer.invoke("fern:updates:has-rollback"),
  deferUpdate: (version) => import_electron.ipcRenderer.invoke("fern:updates:defer", version),
  downloadAndValidateUpdate: (release) => import_electron.ipcRenderer.invoke("fern:updates:download-and-validate", release),
  onUpdateDownloadProgress: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:update-download-progress", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:update-download-progress", handler);
  },
  // Phase 8 - Backups
  listBackups: () => import_electron.ipcRenderer.invoke("fern:backups:list"),
  createConfigBackup: (name) => import_electron.ipcRenderer.invoke("fern:backups:create-config", name),
  createInstallationBackup: (instId, opts) => import_electron.ipcRenderer.invoke("fern:backups:create-installation", instId, opts),
  validateBackup: (id) => import_electron.ipcRenderer.invoke("fern:backups:validate", id),
  restoreBackup: (id) => import_electron.ipcRenderer.invoke("fern:backups:restore", id),
  deleteBackup: (id) => import_electron.ipcRenderer.invoke("fern:backups:delete", id),
  // Phase 8 - Cache & Disk
  getCacheBreakdown: () => import_electron.ipcRenderer.invoke("fern:cache:get-breakdown"),
  clearSafeCache: () => import_electron.ipcRenderer.invoke("fern:cache:clear-safe"),
  checkDiskSpace: (targetPath, requiredBytes) => import_electron.ipcRenderer.invoke("fern:disk:check-space", targetPath, requiredBytes),
  // Phase 8 & 11 - Diagnostics & Feedback
  generateDiagnosticReport: (instId) => import_electron.ipcRenderer.invoke("fern:diagnostics:generate", instId),
  sanitizeDiagnosticText: (text) => import_electron.ipcRenderer.invoke("fern:diagnostics:sanitize-text", text),
  exportDiagnosticReportFile: (destPath, instId) => import_electron.ipcRenderer.invoke("fern:diagnostics:export-file", destPath, instId),
  submitFeedback: (payload) => import_electron.ipcRenderer.invoke("fern:feedback:submit", payload),
  listLocalFeedbackReports: () => import_electron.ipcRenderer.invoke("fern:feedback:list-local"),
  // Phase 8 - Crash Analysis
  analyzeCrash: (gameDir, exitCode) => import_electron.ipcRenderer.invoke("fern:crash:analyze", gameDir, exitCode),
  // Phase 8 - Import & Export
  exportInstallationPackage: (id) => import_electron.ipcRenderer.invoke("fern:import-export:export-installation", id),
  exportProfilePackage: (id) => import_electron.ipcRenderer.invoke("fern:import-export:export-profile", id),
  importPackage: (rawJson) => import_electron.ipcRenderer.invoke("fern:import-export:import-package", rawJson),
  // Phase 8 - JVM Arguments
  validateJvmArgs: (args, javaVersion) => import_electron.ipcRenderer.invoke("fern:jvm:validate-args", args, javaVersion),
  // Phase 8 - Java Manager
  addJavaRuntimeManually: (customPath) => import_electron.ipcRenderer.invoke("fern:java:add-manually", customPath),
  removeJavaRuntime: (idOrPath) => import_electron.ipcRenderer.invoke("fern:java:remove", idOrPath),
  setDefaultJavaRuntime: (idOrPath) => import_electron.ipcRenderer.invoke("fern:java:set-default", idOrPath),
  checkJavaAvailability: (mcVersion) => import_electron.ipcRenderer.invoke("fern:java:check-availability", mcVersion),
  // Phase 8 - Accounts
  addMicrosoftAccount: (name, uuid, tokens) => import_electron.ipcRenderer.invoke("fern:accounts:add-microsoft", name, uuid, tokens),
  hasValidSession: (accountId) => import_electron.ipcRenderer.invoke("fern:accounts:has-valid-session", accountId),
  // Phase 9 - Social & Profile
  getUserProfile: async () => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:get-profile");
    return res.data;
  },
  updateUserProfile: async (dto) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:update-profile", dto);
    return res.data;
  },
  getPublicProfile: async (userId) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:get-public-profile", userId);
    return res.data;
  },
  // Phase 9 - Friends
  getFriends: async () => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:get-friends");
    return res.data || [];
  },
  sendFriendRequest: async (targetUsername) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:send-request", targetUsername);
    if (!res.success) throw new Error(res.error || "Failed to send friend request");
    return res.data;
  },
  respondFriendRequest: async (requestId, accept) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:respond-request", requestId, accept);
    return res.success;
  },
  cancelFriendRequest: async (requestId) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:cancel-request", requestId);
    return res.success;
  },
  removeFriend: async (friendId) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:remove-friend", friendId);
    return res.success;
  },
  getFriendRequests: async () => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:get-requests");
    return res.data || [];
  },
  searchUsers: async (query) => {
    const res = await import_electron.ipcRenderer.invoke("fern:social:search-users", query);
    return res.data || [];
  },
  // Phase 9 - Blocking
  getBlockedUsers: () => import_electron.ipcRenderer.invoke("fern:social:get-blocked"),
  blockUser: (userId, username, displayName, reason) => import_electron.ipcRenderer.invoke("fern:social:block-user", userId, username, displayName, reason),
  unblockUser: (userId) => import_electron.ipcRenderer.invoke("fern:social:unblock-user", userId),
  // Phase 9 - Presence & Privacy
  getUserPresence: () => import_electron.ipcRenderer.invoke("fern:social:get-presence"),
  setUserPresenceState: (state) => import_electron.ipcRenderer.invoke("fern:social:set-presence-state", state),
  getSocialPrivacy: () => import_electron.ipcRenderer.invoke("fern:social:get-privacy"),
  updateSocialPrivacy: (settings) => import_electron.ipcRenderer.invoke("fern:social:update-privacy", settings),
  // Phase 9 - Statistics
  getPlayerStatistics: () => import_electron.ipcRenderer.invoke("fern:social:get-statistics"),
  resetPlayerStatistics: () => import_electron.ipcRenderer.invoke("fern:social:reset-statistics"),
  // Phase 9 - Cosmetics
  getCosmeticsCatalog: async (category) => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:get-catalog", category);
    return res.data || [];
  },
  getOwnedCosmetics: async () => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:get-owned");
    return res.data;
  },
  getEquippedCosmetics: async () => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:get-equipped");
    return res.data;
  },
  equipCosmetic: async (category, cosmeticId) => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:equip", category, cosmeticId);
    return res.success;
  },
  unequipCosmetic: async (category) => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:unequip", category);
    return res.success;
  },
  toggleFavoriteCosmetic: async (cosmeticId) => {
    const res = await import_electron.ipcRenderer.invoke("fern:cosmetics:toggle-favorite", cosmeticId);
    return res.success;
  },
  getInGameCosmeticsPayload: (playerModel) => import_electron.ipcRenderer.invoke("fern:cosmetics:get-ingame-payload", playerModel),
  // Phase 9 - Social Notifications
  getSocialNotifications: () => import_electron.ipcRenderer.invoke("fern:social:get-notifications"),
  markSocialNotificationRead: (id) => import_electron.ipcRenderer.invoke("fern:social:mark-read", id),
  markAllSocialNotificationsRead: () => import_electron.ipcRenderer.invoke("fern:social:mark-all-read"),
  clearSocialNotifications: () => import_electron.ipcRenderer.invoke("fern:social:clear-notifications"),
  getSocialNotificationPreferences: () => import_electron.ipcRenderer.invoke("fern:social:get-notification-prefs"),
  updateSocialNotificationPreferences: (prefs) => import_electron.ipcRenderer.invoke("fern:social:update-notification-prefs", prefs),
  // Phase 10 - Network & Connection
  getNetworkStatus: () => import_electron.ipcRenderer.invoke("fern:network:get-status"),
  checkNetworkStatus: () => import_electron.ipcRenderer.invoke("fern:network:check"),
  onNetworkStatusChanged: (callback) => {
    const handler = (_, val) => callback(val);
    import_electron.ipcRenderer.on("fern:network-status-changed", handler);
    return () => import_electron.ipcRenderer.removeListener("fern:network-status-changed", handler);
  },
  // Phase 10 - Fern Authentication
  fernRegister: (dto) => import_electron.ipcRenderer.invoke("fern:auth:register", dto),
  fernLogin: (dto) => import_electron.ipcRenderer.invoke("fern:auth:login", dto),
  fernLogout: () => import_electron.ipcRenderer.invoke("fern:auth:logout"),
  getFernSession: () => import_electron.ipcRenderer.invoke("fern:auth:get-session"),
  getFernUser: () => import_electron.ipcRenderer.invoke("fern:auth:get-user"),
  verifyFernEmail: (token) => import_electron.ipcRenderer.invoke("fern:auth:verify-email", token),
  requestFernPasswordReset: (ident) => import_electron.ipcRenderer.invoke("fern:auth:request-password-reset", ident),
  confirmFernPasswordReset: (token, newPass) => import_electron.ipcRenderer.invoke("fern:auth:confirm-password-reset", token, newPass),
  deleteFernAccount: (pass) => import_electron.ipcRenderer.invoke("fern:auth:delete-account", pass),
  listFernSessions: () => import_electron.ipcRenderer.invoke("fern:auth:list-sessions"),
  revokeFernSession: (id) => import_electron.ipcRenderer.invoke("fern:auth:revoke-session", id),
  // Phase 10 - Cloud Sync
  getCloudSyncStatus: () => import_electron.ipcRenderer.invoke("fern:sync:get-status"),
  enableCloudSync: () => import_electron.ipcRenderer.invoke("fern:sync:enable"),
  disableCloudSync: () => import_electron.ipcRenderer.invoke("fern:sync:disable"),
  pushCloudSync: (force) => import_electron.ipcRenderer.invoke("fern:sync:push", force),
  pullCloudSync: (revId) => import_electron.ipcRenderer.invoke("fern:sync:pull", revId),
  resolveCloudSyncConflict: (strategy) => import_electron.ipcRenderer.invoke("fern:sync:resolve-conflict", strategy),
  resetCloudSync: () => import_electron.ipcRenderer.invoke("fern:sync:reset")
};
import_electron.contextBridge.exposeInMainWorld("fern", api);
